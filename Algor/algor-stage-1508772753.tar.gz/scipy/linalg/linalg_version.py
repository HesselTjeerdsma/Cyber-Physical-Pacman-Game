from __future__ import division, print_function, absolute_import

major = 0
minor = 4
micro = 9

linalg_version = '%(major)d.%(minor)d.%(micro)d' % (locals())
